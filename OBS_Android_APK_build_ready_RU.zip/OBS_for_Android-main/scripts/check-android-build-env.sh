#!/usr/bin/env bash
# Read-only preflight check for the OBS Android APK build environment.
set +e
printf '%s\n' 'Проверка окружения сборки OBS Android APK' '========================================='
for cmd in java cmake ninja gradle python3; do
  if command -v "$cmd" >/dev/null 2>&1; then
    printf '[OK] %s: %s\n' "$cmd" "$(command -v "$cmd")"
  else
    printf '[НЕТ] %s не найден в PATH\n' "$cmd"
  fi
done
printf '\nПеременные окружения:\n'
for var in ANDROID_SDK_ROOT QT_DIR QT_HOST_PATH NDK_ROOT JAVA_HOME; do
  value="${!var:-}"
  if [ -n "$value" ]; then printf '[OK] %s=%s\n' "$var" "$value"; else printf '[НЕТ] %s не задана\n' "$var"; fi
done
printf '\nОжидаемые пути (если переменные заданы):\n'
[ -n "${ANDROID_SDK_ROOT:-}" ] && [ -d "$ANDROID_SDK_ROOT" ] && echo '[OK] Android SDK path exists' || echo '[НЕТ] Android SDK directory not confirmed'
[ -n "${QT_DIR:-}" ] && [ -d "$QT_DIR/android_arm64_v8a" ] && echo '[OK] Qt Android arm64 directory exists' || echo '[НЕТ] Qt Android arm64 directory not confirmed'
[ -n "${QT_HOST_PATH:-}" ] && [ -d "$QT_HOST_PATH" ] && echo '[OK] Qt host directory exists' || echo '[НЕТ] Qt host directory not confirmed'
[ -n "${NDK_ROOT:-}" ] && [ -f "$NDK_ROOT/build/cmake/android.toolchain.cmake" ] && echo '[OK] Android NDK toolchain exists' || echo '[НЕТ] Android NDK toolchain not confirmed'
printf '\nЭта проверка не собирает APK и не проверяет реальную запись экрана.\n'
